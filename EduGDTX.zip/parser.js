// Nhận diện câu hỏi từ văn bản (Word / PDF / dán trực tiếp)
const T=s=>String(s||'').replace(/\u00a0/g,' ').trim();
const LET='A-Za-zÀ-ỹ';

// HTML (từ mammoth) → text; in đậm / gạch chân được đánh dấu bằng \u0001 ... \u0002
function htmlToText(h){
  return String(h).replace(/<\/p>|<br\s*\/?>|<\/li>|<\/tr>/gi,'\n')
    .replace(/<(strong|b|u)>/gi,'\u0001').replace(/<\/(strong|b|u)>/gi,'\u0002')
    .replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&amp;/g,'&');
}
// "a-Đ b-S c-Đ d-S" | "ĐSĐS" | "a) Đúng b) Sai ..." → "DSDS"
function tfKey(s){
  s=String(s).replace(/Đúng/gi,'Đ').replace(/Sai/gi,'S');
  const o={};let m;const re=/([a-d])\s*[)\-–:=.]?\s*([ĐSđs])/gi;
  while((m=re.exec(s)))o[m[1].toLowerCase()]=m[2].toUpperCase();
  const conv=x=>x.replace(/Đ/g,'D');
  if(['a','b','c','d'].every(k=>o[k]))return conv('abcd'.split('').map(k=>o[k]).join(''));
  const c=s.replace(/[^ĐSđs]/g,'').toUpperCase();return c.length==4?conv(c):'';
}
function parseQuestions(text){
  const raw=String(text).replace(/\r/g,'').split('\n');
  const ki=raw.findIndex(l=>{const t=T(l.replace(/[\u0001\u0002]/g,''));return t&&t==t.toUpperCase()&&/^(BẢNG\s+)?(ĐÁP\s*ÁN|LỜI\s*GIẢI|HƯỚNG\s*DẪN\s*GIẢI)([^:]{0,40})?:?$/.test(t)});
  const body=ki<0?raw:raw.slice(0,ki),keyText=ki<0?'':raw.slice(ki+1).join(' ');
  const qs=[];let cur=null,last='c';
  for(const L of body){
    const star=/^[\u0001\u0002\s]*\*/.test(L),bold=/^\s*\u0001/.test(L);
    const line=T(L.replace(/[\u0001\u0002]/g,'').replace(/^\s*\*\s*/,''));if(!line)continue;
    let m=line.match(/^(?:Câu|Bài|Question)\s*(\d+)\s*[.:)\-–]?\s*(.*)$/i);
    if(m){cur={num:+m[1],content:m[2],opts:[],flags:[],stm:[],key:null};qs.push(cur);last='c';continue}
    if(!cur)continue;
    m=line.match(/^(?:Đáp\s*án|ĐA|Lời\s*giải|Key)(?:\s*đúng)?\s*[:：.\-]\s*(.*)$/i);
    if(m){cur.key=m[1];last='k';continue}
    if(/^[A-D][.)]\s/.test(line)){
      line.split(/\s+(?=[B-D][.)]\s)/).forEach((p,i)=>{const o=p.match(/^([A-D])[.)]\s*(.*)$/);if(o){cur.opts.push(o[2]);cur.flags.push(i==0&&(star||bold))}});last='o';continue}
    if(/^[a-d][.)]\s/.test(line)){cur.stm.push(line.replace(/^[a-d][.)]\s*/,''));last='s';continue}
    if(last=='o'&&cur.opts.length)cur.opts[cur.opts.length-1]+=' '+line;
    else if(last=='s'&&cur.stm.length)cur.stm[cur.stm.length-1]+=' '+line;
    else if(last=='k')cur.key+=' '+line;
    else cur.content+='\n'+line;
  }
  const gk={};
  if(keyText){const re=/(?:Câu\s*)?(\d{1,3})\s*[.:\-–)]\s*([^\d]*?)(?=\s*(?:Câu\s*)?\d{1,3}\s*[.:\-–)]|$)/gs;let m;while((m=re.exec(keyText)))gk[+m[1]]=m[2].trim()}
  return qs.map(q=>{
    const key=T(q.key||gk[q.num]||'');
    let content=T(q.content),points=null;
    const pm=content.match(/\(\s*(\d+(?:[.,]\d+)?)\s*điểm\s*\)/i);
    if(pm){points=+pm[1].replace(',','.');content=T(content.replace(pm[0],''))}
    const warn=[];
    if(q.stm.length>=4){
      const k=tfKey(key);if(!k)warn.push('Chưa nhận diện được đáp án Đúng/Sai');
      return{type:'tf',content,options:q.stm.slice(0,4),key:k||'DDDD',answer:0,points,model:'',warn}}
    if(q.opts.length>=2){
      const o=q.opts.slice(0,4);while(o.length<4)o.push('');
      let a=-1;const Lt=(key.match(new RegExp(`(?:^|[^${LET}])([A-D])(?![${LET}])`))||[])[1];
      if(Lt)a='ABCD'.indexOf(Lt);else{const f=q.flags.map((x,i)=>x?i:-1).filter(i=>i>=0);if(f.length==1)a=f[0]}
      if(a<0)warn.push('Chưa có đáp án đúng');if(q.opts.length<4)warn.push('Thiếu đáp án');
      return{type:'mc',content,options:o,answer:a,key:null,points,model:'',warn}}
    return{type:'essay',content,options:[],answer:0,key:null,points,model:key,warn:[]}
  });
}
module.exports={parseQuestions,htmlToText,tfKey};

const parser=require('./parser');
const express=require('express'),crypto=require('crypto'),bcrypt=require('bcryptjs'),db=require('./db');
const app=express();app.use(express.json({limit:'1mb'}));app.use(express.static(__dirname+'/public'));
const fail=(r,c,m)=>r.status(c).json({error:m});
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const pub=u=>({id:u.id,username:u.username,name:u.name,role:u.role,class_id:u.class_id});
const auth=(...roles)=>(q,r,n)=>{
  const t=(q.headers.authorization||'').slice(7);
  const u=t&&db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?').get(t);
  if(!u)return fail(r,401,'Chưa đăng nhập');
  if(u.locked)return fail(r,403,'Tài khoản đã bị khóa. Liên hệ quản trị viên để được mở khóa.');
  if(roles.length&&!roles.includes(u.role))return fail(r,403,'Không có quyền');
  q.user=u;n();
};

/* Đăng nhập */
app.post('/api/login',(q,r)=>{
  const u=db.prepare('SELECT * FROM users WHERE username=?').get(String(q.body.username||'').trim());
  if(!u||!bcrypt.compareSync(String(q.body.password||''),u.password)||!!q.body.admin!==(u.role=='admin'))return fail(r,401,'Sai tên đăng nhập hoặc mật khẩu');
  if(u.locked)return fail(r,403,'Tài khoản đã bị khóa (đình chỉ)'+(u.lock_reason?': '+u.lock_reason:'')+'. Liên hệ quản trị viên để được mở khóa.');
  const token=crypto.randomBytes(24).toString('hex');
  db.prepare('INSERT INTO sessions VALUES(?,?)').run(token,u.id);r.json({token,user:pub(u)});
});
app.get('/api/me',auth(),(q,r)=>r.json(pub(q.user)));
app.post('/api/logout',auth(),(q,r)=>{db.prepare('DELETE FROM sessions WHERE token=?').run(q.headers.authorization.slice(7));r.json({ok:1})});

/* Admin: lớp + tài khoản */
app.get('/api/classes',auth(),(q,r)=>r.json(db.prepare('SELECT * FROM classes').all()));
app.post('/api/classes',auth('admin'),(q,r)=>{
  try{db.prepare('INSERT INTO classes(name) VALUES(?)').run(String(q.body.name).trim());r.json({ok:1})}
  catch(e){fail(r,400,'Tên lớp đã tồn tại hoặc không hợp lệ')}
});
app.get('/api/users',auth('admin'),(q,r)=>r.json(db.prepare('SELECT u.id,u.username,u.name,u.role,u.locked,u.lock_reason,c.name AS class FROM users u LEFT JOIN classes c ON c.id=u.class_id').all()));
app.post('/api/users',auth('admin'),(q,r)=>{
  const{username,password,name,role,class_id}=q.body;
  if(!username||!password||!name||!['gv','hs'].includes(role))return fail(r,400,'Thiếu thông tin');
  try{db.prepare('INSERT INTO users(username,password,name,role,class_id) VALUES(?,?,?,?,?)').run(username.trim(),bcrypt.hashSync(password,10),name.trim(),role,role=='hs'?class_id||null:null);r.json({ok:1})}
  catch(e){fail(r,400,'Tên đăng nhập đã tồn tại')}
});
app.delete('/api/users/:id',auth('admin'),(q,r)=>{db.prepare("DELETE FROM users WHERE id=? AND role!='admin'").run(q.params.id);r.json({ok:1})});

/* Giáo viên: giao bài */
app.get('/api/exams',auth('gv','admin'),(q,r)=>r.json(db.prepare(`SELECT e.*,c.name AS class,
  (SELECT COUNT(*) FROM questions WHERE exam_id=e.id) AS qcount,
  (SELECT COUNT(DISTINCT user_id) FROM attempts WHERE exam_id=e.id AND submitted_at IS NOT NULL) AS done
  FROM exams e JOIN classes c ON c.id=e.class_id ORDER BY e.id DESC`).all()));
/* ---- Bài: tạo, xem, sửa ---- */
function cleanQ(x){
  const type=['mc','tf','essay'].includes(x.type)?x.type:'mc',content=String(x.content||'').trim();if(!content)return null;
  const points=Math.max(0.25,+x.points||1);
  if(type=='essay')return{type,content,options:[],answer:0,key:null,points,model:String(x.model||'').slice(0,2000)};
  const o=(x.options||[]).map(v=>String(v).trim());if(o.length!=4||o.some(v=>!v))return null;
  if(type=='mc')return Number.isInteger(x.answer)&&x.answer>=0&&x.answer<4?{type,content,options:o,answer:x.answer,key:null,points,model:null}:null;
  return /^[DS]{4}$/.test(x.key)?{type,content,options:o,answer:0,key:x.key,points,model:null}:null;
}
function insQ(examId,qs){const ins=db.prepare('INSERT INTO questions(exam_id,content,options,answer,type,key,points,model) VALUES(?,?,?,?,?,?,?,?)');qs.forEach(x=>ins.run(examId,x.content,JSON.stringify(x.options),x.answer,x.type,x.key,x.points,x.model))}
const cfg=b=>[String(b.title||'').trim(),+b.class_id,Math.max(1,+b.minutes||15),b.start_at||null,b.deadline||null,b.mode=='practice'?'practice':'exam',b.shuffle===false?0:1,b.show_score===false?0:1,Math.min(Math.max(+b.max_viol||3,1),20),String(b.code||'').trim()||null];
app.post('/api/exams',auth('gv'),(q,r)=>{
  const qs=(q.body.questions||[]).map(cleanQ).filter(Boolean),c=cfg(q.body);
  if(!c[0]||!c[1]||!qs.length)return fail(r,400,'Cần tên bài, lớp và ít nhất 1 câu hợp lệ');
  let newId;
  db.transaction(()=>{
    const id=db.prepare('INSERT INTO exams(title,class_id,minutes,start_at,deadline,mode,shuffle,show_score,max_viol,code,teacher_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(...c,q.user.id).lastInsertRowid;
    newId=Number(id);insQ(id,qs);
  })();
  r.json({ok:1,id:newId});
});
app.get('/api/exams/:id',auth('gv'),(q,r)=>{
  const e=db.prepare('SELECT * FROM exams WHERE id=?').get(q.params.id);if(!e)return fail(r,404,'Không có bài');
  const qs=db.prepare('SELECT type,content,options,answer,key,points,model FROM questions WHERE exam_id=? ORDER BY id').all(e.id).map(x=>({...x,options:JSON.parse(x.options)}));
  r.json({exam:e,questions:qs,locked:!!db.prepare('SELECT 1 FROM attempts WHERE exam_id=?').get(e.id)});
});
app.put('/api/exams/:id',auth('gv'),(q,r)=>{
  const e=db.prepare('SELECT * FROM exams WHERE id=?').get(q.params.id);if(!e)return fail(r,404,'Không có bài');
  const locked=!!db.prepare('SELECT 1 FROM attempts WHERE exam_id=?').get(e.id),c=cfg(q.body);
  const qs=locked?null:(q.body.questions||[]).map(cleanQ).filter(Boolean);
  if(!c[0]||!c[1]||(!locked&&!qs.length))return fail(r,400,'Cần tên bài, lớp và ít nhất 1 câu hợp lệ');
  db.transaction(()=>{
    db.prepare('UPDATE exams SET title=?,class_id=?,minutes=?,start_at=?,deadline=?,mode=?,shuffle=?,show_score=?,max_viol=?,code=? WHERE id=?').run(...c,e.id);
    if(!locked){db.prepare('DELETE FROM questions WHERE exam_id=?').run(e.id);insQ(e.id,qs)}
  })();
  r.json({ok:1,locked});
});
app.delete('/api/exams/:id',auth('gv'),(q,r)=>{db.prepare('DELETE FROM exams WHERE id=?').run(q.params.id);r.json({ok:1})});
app.get('/api/exams/:id/results',auth('gv'),(q,r)=>{
  const e=db.prepare('SELECT * FROM exams WHERE id=?').get(q.params.id);if(!e)return fail(r,404,'Không có bài');
  r.json({exam:e,rows:db.prepare(`SELECT u.name,u.locked,a.id AS attempt_id,a.pending,a.score,a.correct,a.total,a.violations,a.submitted_at FROM users u
    LEFT JOIN attempts a ON a.id=(SELECT id FROM attempts WHERE exam_id=? AND user_id=u.id AND submitted_at IS NOT NULL ORDER BY id DESC LIMIT 1)
    WHERE u.role='hs' AND u.class_id=?`).all(e.id,e.class_id)});
});

/* Học sinh: làm bài (đáp án đúng chỉ nằm ở server) */
app.get('/api/my-exams',auth('hs'),(q,r)=>r.json(db.prepare(`SELECT e.id,e.title,e.minutes,e.deadline,e.start_at,e.mode,(e.code IS NOT NULL AND e.code!='') AS has_code,
  (SELECT COUNT(*) FROM questions WHERE exam_id=e.id) AS qcount,
  (SELECT COUNT(*) FROM attempts WHERE exam_id=e.id AND user_id=? AND submitted_at IS NOT NULL) AS tries,
  CASE WHEN e.mode='exam' AND e.show_score=0 THEN NULL ELSE (SELECT score FROM attempts WHERE exam_id=e.id AND user_id=? AND submitted_at IS NOT NULL ORDER BY id DESC LIMIT 1) END AS score,
  (SELECT pending FROM attempts WHERE exam_id=e.id AND user_id=? AND submitted_at IS NOT NULL ORDER BY id DESC LIMIT 1) AS pending
  FROM exams e WHERE e.class_id=? ORDER BY e.id DESC`).all(q.user.id,q.user.id,q.user.id,q.user.class_id)));
app.get('/api/exams/:id/start',auth('hs'),(q,r)=>{
  const e=db.prepare('SELECT * FROM exams WHERE id=? AND class_id=?').get(q.params.id,q.user.class_id);
  if(!e)return fail(r,404,'Không tìm thấy bài');
  if(e.mode=='exam'){
    if(e.start_at&&new Date(e.start_at)>new Date())return fail(r,400,'Bài chưa đến giờ mở');
    if(e.deadline&&new Date(e.deadline)<new Date())return fail(r,400,'Bài đã quá hạn');
    if(db.prepare('SELECT 1 FROM attempts WHERE exam_id=? AND user_id=? AND submitted_at IS NOT NULL').get(e.id,q.user.id))return fail(r,400,'Bạn đã nộp bài này rồi');
  }
  if(e.code&&String(q.query.code||'')!==e.code)return fail(r,400,'Sai mã vào bài');
  let at=e.mode=='exam'?db.prepare('SELECT * FROM attempts WHERE exam_id=? AND user_id=? AND submitted_at IS NULL').get(e.id,q.user.id):null;
  let viol=0;
  if(at){   // vào lại bài đang làm dở = đã rời khỏi trang → tính 1 vi phạm
    db.prepare('INSERT INTO violations(attempt_id,user_id,kind,at) VALUES(?,?,?,?)').run(at.id,q.user.id,'reload',Date.now());
    db.prepare('UPDATE attempts SET violations=COALESCE(violations,0)+1 WHERE id=?').run(at.id);
    viol=db.prepare('SELECT violations v FROM attempts WHERE id=?').get(at.id).v;
    if(viol>=(e.max_viol||3)){gradeAttempt(at,e,{});lockUser(q.user.id,`rời khỏi bài thi "${e.title}" ${viol} lần`);return fail(r,403,'Bạn đã rời khỏi bài thi quá số lần cho phép. Bài đã được nộp và tài khoản bị đình chỉ, khóa.')}
  }
  if(!at){const t=Date.now();at={id:db.prepare('INSERT INTO attempts(exam_id,user_id,started_at) VALUES(?,?,?)').run(e.id,q.user.id,t).lastInsertRowid,started_at:t}}
  let qs=db.prepare('SELECT id,type,content,options,points FROM questions WHERE exam_id=? ORDER BY id').all(e.id).map(x=>({...x,options:JSON.parse(x.options)}));
  if(e.shuffle)shuffle(qs);
  r.json({attempt:at.id,title:e.title,mode:e.mode,endsAt:at.started_at+e.minutes*60000,maxViol:e.max_viol||3,viol,questions:qs});
});
function lockUser(uid,reason){
  db.prepare("UPDATE users SET locked=1,lock_reason=? WHERE id=? AND role!='admin'").run(String(reason||'').slice(0,200)||null,uid);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(uid);
}
function gradeAttempt(at,e,ansRaw){
  const practice=e.mode=='practice';
  const late=Date.now()>at.started_at+e.minutes*60000+15000;            // nộp quá giờ → không tính bài làm
  const ans=late?{}:(ansRaw||{});
  const qs=db.prepare('SELECT * FROM questions WHERE exam_id=? ORDER BY id').all(e.id);
  const ia=db.prepare('INSERT OR REPLACE INTO answers(attempt_id,question_id,picked,text,earned) VALUES(?,?,?,?,?)');
  let earned=0,total=0,correct=0,pending=0;const review=[];
  db.transaction(()=>{for(const x of qs){
    const a=ans[x.id];let got=null,picked=null,text=null;
    if(x.type=='essay'){text=typeof a=='string'?a.slice(0,5000):'';if(!practice){total+=x.points;pending=1}}   // tự luận: chờ giáo viên chấm
    else if(x.type=='tf'){text=typeof a=='string'&&/^[DS-]{4}$/.test(a)?a:'----';let n=0;for(let i=0;i<4;i++)if(text[i]==x.key[i])n++;
      got=x.points*[0,.1,.25,.5,1][n];total+=x.points;if(n==4)correct++}                                       // đúng sai: 1/2/3/4 ý đúng = 10%/25%/50%/100%
    else{picked=Number.isInteger(a)?a:null;got=picked===x.answer?x.points:0;total+=x.points;if(got)correct++}
    if(got!=null)earned+=got;
    ia.run(at.id,x.id,picked,text,got);
    review.push({type:x.type,content:x.content,options:JSON.parse(x.options),answer:x.answer,key:x.key,points:x.points,model:x.model,picked,text,got});
  }})();
  const score=total?Math.round(earned/total*1000)/100:0;
  db.prepare('UPDATE attempts SET submitted_at=?,score=?,correct=?,total=?,pending=? WHERE id=?').run(Date.now(),score,correct,qs.length,pending,at.id);
  const out={late,pending:!!pending};
  if(!practice&&!e.show_score)out.hidden=true;else Object.assign(out,{score,correct,total:qs.length});
  if(practice)out.review=review;
  return out;
}
app.post('/api/attempts/:id/submit',auth('hs'),(q,r)=>{
  const at=db.prepare('SELECT * FROM attempts WHERE id=? AND user_id=?').get(q.params.id,q.user.id);
  if(!at||at.submitted_at)return fail(r,400,'Bài đã nộp hoặc không hợp lệ');
  r.json(gradeAttempt(at,db.prepare('SELECT * FROM exams WHERE id=?').get(at.exam_id),q.body.answers));
});
// Chống gian lận: ghi nhận vi phạm (chuyển tab, rời cửa sổ, thoát toàn màn hình). Đủ số lần → nộp bài + đình chỉ + khóa tài khoản
app.post('/api/attempts/:id/violation',auth('hs'),(q,r)=>{
  const at=db.prepare('SELECT * FROM attempts WHERE id=? AND user_id=? AND submitted_at IS NULL').get(q.params.id,q.user.id);
  const e=at&&db.prepare('SELECT * FROM exams WHERE id=?').get(at.exam_id);
  if(!at||e.mode!='exam')return r.json({ignored:true});
  const kind=['tab','blur','fullscreen'].includes(q.body.kind)?q.body.kind:'tab',max=e.max_viol||3;
  db.prepare('INSERT INTO violations(attempt_id,user_id,kind,at) VALUES(?,?,?,?)').run(at.id,q.user.id,kind,Date.now());
  db.prepare('UPDATE attempts SET violations=COALESCE(violations,0)+1 WHERE id=?').run(at.id);
  const n=db.prepare('SELECT violations v FROM attempts WHERE id=?').get(at.id).v;
  if(n>=max){gradeAttempt(at,e,q.body.answers);lockUser(q.user.id,`rời khỏi bài thi "${e.title}" ${n} lần`);return r.json({locked:true,count:n,max})}
  r.json({count:n,max});
});
// Admin: khóa / mở khóa tài khoản
app.post('/api/users/:id/lock',auth('admin'),(q,r)=>{
  const u=db.prepare("SELECT * FROM users WHERE id=? AND role!='admin'").get(q.params.id);if(!u)return fail(r,404,'Không tìm thấy tài khoản');
  if(q.body.locked)lockUser(u.id,String(q.body.reason||'Bị quản trị viên khóa'));
  else db.prepare('UPDATE users SET locked=0,lock_reason=NULL WHERE id=?').run(u.id);
  r.json({ok:1});
});

/* ===== Tính năng mở rộng ===== */
app.post('/api/password',auth(),(q,r)=>{
  const{old,pw}=q.body;
  if(!bcrypt.compareSync(String(old||''),q.user.password))return fail(r,400,'Mật khẩu hiện tại không đúng');
  if(String(pw||'').length<6)return fail(r,400,'Mật khẩu mới phải từ 6 ký tự');
  db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(pw,10),q.user.id);r.json({ok:1});
});
// Admin
app.get('/api/stats',auth('admin'),(q,r)=>r.json({exams:db.prepare('SELECT COUNT(*) n FROM exams').get().n,attempts:db.prepare('SELECT COUNT(*) n FROM attempts WHERE submitted_at IS NOT NULL').get().n}));
app.post('/api/users/:id/reset',auth('admin'),(q,r)=>{
  const pw='Edu'+crypto.randomInt(100000,999999);
  const c=db.prepare("UPDATE users SET password=? WHERE id=? AND role!='admin'").run(bcrypt.hashSync(pw,10),q.params.id);
  if(!c.changes)return fail(r,404,'Không tìm thấy tài khoản');
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(q.params.id);r.json({password:pw});
});
app.delete('/api/classes/:id',auth('admin'),(q,r)=>{db.prepare('DELETE FROM classes WHERE id=?').run(q.params.id);r.json({ok:1})});
// Giáo viên
app.post('/api/exams/:id/duplicate',auth('gv'),(q,r)=>{
  const e=db.prepare('SELECT * FROM exams WHERE id=?').get(q.params.id);
  if(!e||!db.prepare('SELECT 1 FROM classes WHERE id=?').get(q.body.class_id))return fail(r,404,'Không tìm thấy bài hoặc lớp');
  db.transaction(()=>{
    const id=db.prepare('INSERT INTO exams(title,class_id,teacher_id,minutes,start_at,deadline,mode,shuffle,show_score,max_viol,code) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(e.title,q.body.class_id,q.user.id,e.minutes,e.start_at,e.deadline,e.mode,e.shuffle,e.show_score,e.max_viol,e.code).lastInsertRowid;
    db.prepare('INSERT INTO questions(exam_id,content,options,answer,type,key,points,model) SELECT ?,content,options,answer,type,key,points,model FROM questions WHERE exam_id=?').run(id,e.id);
  })();r.json({ok:1});
});
app.get('/api/exams/:id/stats',auth('gv'),(q,r)=>r.json(db.prepare(`SELECT q.id,q.type,q.content,COUNT(a.attempt_id) n,COALESCE(SUM(CASE WHEN a.earned IS NOT NULL AND a.earned>=q.points THEN 1 ELSE 0 END),0) ok
  FROM questions q LEFT JOIN (SELECT an.attempt_id,an.question_id,an.picked,an.earned FROM answers an JOIN attempts t ON t.id=an.attempt_id WHERE t.submitted_at IS NOT NULL) a ON a.question_id=q.id
  WHERE q.exam_id=? GROUP BY q.id ORDER BY q.id`).all(q.params.id)));
app.get('/api/announcements',auth('gv','hs'),(q,r)=>r.json(q.user.role=='gv'
  ?db.prepare('SELECT n.*,c.name AS class FROM announcements n JOIN classes c ON c.id=n.class_id WHERE n.teacher_id=? ORDER BY n.id DESC').all(q.user.id)
  :db.prepare('SELECT n.*,u.name AS teacher FROM announcements n JOIN users u ON u.id=n.teacher_id WHERE n.class_id=? ORDER BY n.id DESC').all(q.user.class_id)));
app.post('/api/announcements',auth('gv'),(q,r)=>{
  const c=String(q.body.content||'').trim();if(!c||!q.body.class_id)return fail(r,400,'Nhập nội dung và chọn lớp');
  db.prepare('INSERT INTO announcements(class_id,teacher_id,content,created_at) VALUES(?,?,?,?)').run(q.body.class_id,q.user.id,c.slice(0,1000),Date.now());r.json({ok:1});
});
app.delete('/api/announcements/:id',auth('gv'),(q,r)=>{db.prepare('DELETE FROM announcements WHERE id=? AND teacher_id=?').run(q.params.id,q.user.id);r.json({ok:1})});
// Học sinh
app.get('/api/my-history',auth('hs'),(q,r)=>r.json(db.prepare(`SELECT a.id,e.title,e.mode,a.pending,
  CASE WHEN e.mode='exam' AND e.show_score=0 THEN NULL ELSE a.score END AS score,CASE WHEN e.mode='exam' AND e.show_score=0 THEN NULL ELSE a.correct END AS correct,a.total,a.submitted_at
  FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.user_id=? AND a.submitted_at IS NOT NULL ORDER BY a.id DESC`).all(q.user.id)));
app.get('/api/attempts/:id/review',auth('hs'),(q,r)=>{
  const a=db.prepare('SELECT a.*,e.title,e.mode FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.id=? AND a.user_id=? AND a.submitted_at IS NOT NULL').get(q.params.id,q.user.id);
  if(!a)return fail(r,404,'Không tìm thấy bài làm');
  if(a.mode!='practice')return fail(r,403,'Bài kiểm tra không cho xem lại đáp án');
  const items=db.prepare('SELECT q.type,q.content,q.options,q.answer,q.key,q.points,q.model,an.picked,an.text,an.earned AS got FROM questions q LEFT JOIN answers an ON an.question_id=q.id AND an.attempt_id=? WHERE q.exam_id=? ORDER BY q.id').all(a.id,a.exam_id).map(x=>({...x,options:JSON.parse(x.options)}));
  r.json({title:a.title,score:a.score,correct:a.correct,total:a.total,items});
});
app.get('/api/leaderboard',auth('hs'),(q,r)=>r.json(db.prepare(`SELECT u.id,u.name,ROUND(AVG(a.score),1) avg,COUNT(a.id) n FROM users u LEFT JOIN attempts a ON a.user_id=u.id AND a.submitted_at IS NOT NULL WHERE u.role='hs' AND u.class_id=? GROUP BY u.id ORDER BY avg IS NULL,avg DESC,n DESC`).all(q.user.class_id)));

// Giáo viên: chấm bài tự luận
app.get('/api/attempts/:id/grading',auth('gv'),(q,r)=>{
  const a=db.prepare('SELECT a.*,u.name,e.title FROM attempts a JOIN users u ON u.id=a.user_id JOIN exams e ON e.id=a.exam_id WHERE a.id=? AND a.submitted_at IS NOT NULL').get(q.params.id);
  if(!a)return fail(r,404,'Không tìm thấy bài làm');
  const items=db.prepare('SELECT qu.id,qu.type,qu.content,qu.options,qu.key,qu.answer,qu.points,qu.model,an.picked,an.text,an.earned FROM questions qu LEFT JOIN answers an ON an.question_id=qu.id AND an.attempt_id=? WHERE qu.exam_id=? ORDER BY qu.id').all(a.id,a.exam_id).map(x=>({...x,options:JSON.parse(x.options)}));
  r.json({attempt:{id:a.id,exam_id:a.exam_id,name:a.name,title:a.title,score:a.score,pending:a.pending},items,viol:db.prepare('SELECT kind,at FROM violations WHERE attempt_id=? ORDER BY id').all(a.id)});
});
app.post('/api/attempts/:id/grade',auth('gv'),(q,r)=>{
  const a=db.prepare('SELECT * FROM attempts WHERE id=?').get(q.params.id);if(!a)return fail(r,404,'Không tìm thấy bài làm');
  const up=db.prepare('UPDATE answers SET earned=? WHERE attempt_id=? AND question_id=?');
  (q.body.grades||[]).forEach(g=>{const p=db.prepare("SELECT points FROM questions WHERE id=? AND exam_id=? AND type='essay'").get(g.question_id,a.exam_id);if(p)up.run(Math.min(Math.max(+g.earned||0,0),p.points),a.id,g.question_id)});
  const tp=db.prepare('SELECT COALESCE(SUM(points),0) t FROM questions WHERE exam_id=?').get(a.exam_id).t;
  const s=db.prepare('SELECT COALESCE(SUM(earned),0) e,COALESCE(SUM(CASE WHEN earned IS NULL THEN 1 ELSE 0 END),0) np FROM answers WHERE attempt_id=?').get(a.id);
  const score=tp?Math.round(s.e/tp*1000)/100:0;
  db.prepare('UPDATE attempts SET score=?,pending=? WHERE id=?').run(score,s.np>0?1:0,a.id);r.json({score,pending:s.np>0});
});
// Giáo viên: nhập đề từ Word / PDF / văn bản
app.post('/api/parse',auth('gv'),(q,r)=>{
  const qs=parser.parseQuestions(String(q.body.text||''));
  if(!qs.length)return fail(r,400,'Không nhận diện được câu hỏi. Mỗi câu cần bắt đầu bằng "Câu 1."');r.json(qs);
});
app.post('/api/import',auth('gv'),express.raw({type:'application/octet-stream',limit:'20mb'}),async(q,r)=>{
  try{
    const name=String(q.query.name||'').toLowerCase();let text;
    if(name.endsWith('.docx'))text=parser.htmlToText((await require('mammoth').convertToHtml({buffer:q.body},{styleMap:['u => u']})).value);
    else if(name.endsWith('.pdf'))text=(await require('pdf-parse/lib/pdf-parse.js')(q.body)).text;
    else if(name.endsWith('.txt')||name.endsWith('.md'))text=Buffer.from(q.body).toString('utf8');
    else return fail(r,400,'Chỉ hỗ trợ .docx, .pdf, .txt (file .doc cũ hãy lưu lại thành .docx)');
    const qs=parser.parseQuestions(text);
    if(!qs.length)return fail(r,400,'Không nhận diện được câu hỏi trong file. Kiểm tra mỗi câu bắt đầu bằng "Câu 1." (PDF dạng ảnh quét chưa đọc được)');
    r.json({questions:qs,count:qs.length});
  }catch(e){fail(r,400,'Không đọc được file: '+e.message)}
});

app.listen(process.env.PORT||3000,()=>console.log('Chạy tại http://localhost:'+(process.env.PORT||3000)));

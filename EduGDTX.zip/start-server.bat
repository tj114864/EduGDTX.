@echo off
title Website Server - Port 3000

cd /d "D:\VSCODE\web\Edunova"

echo =====================================
echo       DANG KHOI DONG WEBSITE
echo =====================================
echo.

call npm start

echo.
echo Server da dung hoac gap loi.
pause
